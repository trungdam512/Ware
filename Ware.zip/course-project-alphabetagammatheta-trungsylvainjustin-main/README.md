WARÉ

Authors: Justin Potts, Trung Dam, Sylvain Zong-Naba

Project description:
Two players game with a board in which each opponent places 3 markers by turn and try to put them in a row in order to win.

Technology needed to run the code:
Requires Java17 installed and to use a pc for game logo and victory image to be shown What are its technical requirements? To run the game, click run on the main class which is located in the Ware file. 
Acknowledgements: We got help from Perceptor Jeremy; Professor Joslenne Pena for the project. We used Canvas(canvas.com) to make our game logo and got the Trophy image from Google. 

Known issues:
There is nothing that happens when a player does not apply the game rules; they would not be able to place their marker for example if they put it on a spot which already has a marker on it.
Once the player click on the instructions/change name button when they are already playing, the game will restart when they come back to play again 
The lines below the names might not fit well if the name is long, therefore it is preferable to use short names just for aesthetic purposes
For a mac user, they need to change the images files to a jpg format in order for it to be shown when the game is run
The player with the red color always start first. However players can change who is going by changing the order of names manually. 
The way players play the game sometimes can be annoying since two players have to use the same mouse cursor in the same device.

Societal impact:
We realize that our game is based on visual aspects such as the color of our markers and their movements. With this said, people with visual disabilities such as blindness and color blindness would have trouble playing our game.
Our game is a representation of our humor and we used this to express ourselves through our work. With this being said, there are some instances in our game where the language might be a trigger for some people like, “GIVE ME YOUR NAME” or “[instert name] SUCKS!!!”. This might have psychological effects on the users in a negative way. Our game could also be used to be a catalyst for a hostile, competitive environment with language usage. That is not the intention of our project, but an unintended potential consequence. It could be used against people in social settings if they want to bring up the outcomes of our games and the label that was assigned to them for losing the game as well.